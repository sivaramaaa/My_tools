
#define fastbin_index(sz)        ((((unsigned int)(sz)) >> 3) - 2)

#define arena_get(ptr, size) do { \
  Void_t *vptr = NULL; \
  ptr = (mstate)tsd_getspecific(arena_key, vptr); \
  if(ptr && !mutex_trylock(&ptr->mutex)) { \
    THREAD_STAT(++(ptr->stat_lock_direct)); \
  } else \
    ptr = arena_get2(ptr, (size)); \
} while(0)



#define HEAP_MAX_SIZE (1024*1024) /* must be a power of two */

#define heap_for_ptr(ptr) \
 ((heap_info *)((unsigned long)(ptr) & ~(HEAP_MAX_SIZE-1)))

/* check for chunk from non-main arena */
#define chunk_non_main_arena(p) ((p)->size & NON_MAIN_ARENA)

#define arena_for_chunk(ptr) \
 (chunk_non_main_arena(ptr) ? heap_for_ptr(ptr)->ar_ptr : &main_arena)



void _int_free(mstate av, Void_t* mem)
{
  mchunkptr       p;           /* chunk corresponding to mem */
  INTERNAL_SIZE_T size;        /* its size */
  mfastbinptr*    fb;          /* associated fastbin */

  p = mem2chunk(mem);
  size = chunksize(p);

  /*
    If eligible, place chunk on a ****** fastbin ******* so it can be found
    and used quickly in malloc.
  */

  if ((unsigned long)(size) <= (unsigned long)(av->max_fast)

     {

    if (__builtin_expect (chunk_at_offset (p, size)->size <= 2 * SIZE_SZ, 0)
	|| __builtin_expect (chunksize (chunk_at_offset (p, size))
			     >= av->system_mem, 0))
      {
	errstr = "free(): invalid next size (fast)";
	goto errout;
      }

    set_fastchunks(av);
    fb = &(av->fastbins[fastbin_index(size)]);
    /* Another simple check: make sure the top of the bin is not the
       record we are going to add (i.e., double free).  */
    if (__builtin_expect (*fb == p, 0))
      {
	errstr = "double free or corruption (fasttop)";
	goto errout;
      }
    p->fd = *fb;
    *fb = p;
  }
    else 
     {

       
     /* consolidate backward */
     if (!prev_inuse(p)) {
       prevsize = p->prev_size;
       size += prevsize;
       p = chunk_at_offset(p, -((long) prevsize));
       unlink(p, bck, fwd);
     }
 
     if (nextchunk != av->top) {
       /* get and clear inuse bit */
       nextinuse = inuse_bit_at_offset(nextchunk, nextsize);
 
       /* consolidate forward */
       if (!nextinuse) {
         unlink(nextchunk, bck, fwd);
         size += nextsize;
       } else
         clear_inuse_bit_at_offset(nextchunk, );
 
       /*
         Place the chunk in unsorted chunk list. Chunks are
         not placed into regular bins until after they have
         been given one chance to be used in malloc.
       */
 
       bck = unsorted_chunks(av);
       fwd = bck->fd;
       p->bk = bck;
       p->fd = fwd;
       bck->fd = p;
       fwd->bk = p;


     }

}

void
public_fREe(Void_t* mem)
{
  mstate ar_ptr;
  mchunkptr p;                          /* chunk corresponding to mem */

  [...]

  p = mem2chunk(mem);

  [...]

  ar_ptr = arena_for_chunk(p);

  [...]

  _int_free(ar_ptr, mem);
  (void)mutex_unlock(&ar_ptr->mutex);
}


Void_t* public_mALLOc(size_t bytes)
{
  mstate ar_ptr;
  Void_t *victim;

  [...]

  arena_get(ar_ptr, bytes);
  if(!ar_ptr)
    return 0;
  victim = _int_malloc(ar_ptr, bytes);

  [...]

  return victim;
}


Void_t* _int_malloc(mstate av, size_t bytes)
  {
     
     INTERNAL_SIZE_T nb;               /* normalized request size */
      unsigned int    idx;              /* associated bin index */
      mbinptr         bin;              /* associated bin */
      mfastbinptr*    fb;               /* associated fastbin */

      mchunkptr       victim;           /* inspected/selected chunk */

      [...]

      /*
        Convert request size to internal form by adding SIZE_SZ bytes
      */

      checked_request2size(bytes, nb);

      /*
        If the size qualifies as a fastbin, first check corresponding bin.
      */

      if ((unsigned long)(nb) <= (unsigned long)(av->max_fast)) {
        long int idx = fastbin_index(nb);
        fb = &(av->fastbins[idx]);
        if ( (victim = *fb) != 0) {
          if (__builtin_expect (fastbin_index (chunksize (victim)) != idx, 0))
    	malloc_printerr (check_action, "malloc(): memory corruption (fast)",
    			 chunk2mem (victim));
          *fb = victim->fd;
          check_remalloced_chunk(av, victim, nb);
          return chunk2mem(victim);
        }

      else 
       
       {
   for(;;) {

  while ( (victim = unsorted_chunks(av)->bk) != unsorted_chunks(av)) {
    bck = victim->bk;
    if (__builtin_expect (victim->size <= 2 * SIZE_SZ, 0)
        || __builtin_expect (victim->size > av->system_mem, 0))
      malloc_printerr (check_action, "malloc(): memory corruption",
                       chunk2mem (victim));
    size = chunksize(victim);

 

    if (in_smallbin_range(nb) &&
        bck == unsorted_chunks(av) &&
        victim == av->last_remainder &&
        (unsigned long)(size) > (unsigned long)(nb + MINSIZE)) {
        [...]
      }

      /* remove from unsorted list */
      unsorted_chunks(av)->bk = bck;
      bck->fd = unsorted_chunks(av);

      /* Take now instead of binning if exact fit */

      if (size == nb) {
        set_inuse_bit_at_offset(victim, size);
	if (av != &main_arena)
	  victim->size |= NON_MAIN_ARENA;
        check_malloced_chunk(av, victim, nb);
        return chunk2mem(victim);
      }
      [...]



      }

    
