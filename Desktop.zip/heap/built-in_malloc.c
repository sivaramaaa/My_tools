#include<stdio.h>
#include<malloc.h>


void main()
{  int bss_var , ptr_top ;
   bss_var = 0xffffcf3c; 
   ptr_top = 0x804f6b8;
   unsigned long evil_size = (unsigned long)bss_var - sizeof(long)*2 - (unsigned long)ptr_top;
   printf("%#lx bytes", evil_size);
}
