#!/bin/bash

sudo -i -u test

sudo mount /dev/sdb1 /media/restricted/usb

