import java.awt.event.*;  
import javax.swing.*;    

public class note {  

public static void main(String[] args) {  
        JFrame f=new JFrame("Button Example");  
        JLabel l1=new JLabel("Welcome to Secure Copier !!");  
        l1.setBounds(10,10, 200,30);  
        JButton browser =new JButton("File Browser");  
        browser.setBounds(50,100,150,50);
        JButton auth =new JButton("Register");
        auth.setBounds(50,180,150,50); 
        final JTextField text =new JTextField();  
        text.setBounds(50,50,250,30);   
        browser.addActionListener(new ActionListener(){  
public void actionPerformed(ActionEvent e){  
            text.setText("Action Trigered ...");  
        }  
    });   
        f.add(browser); 
        f.add(l1);
        f.add(auth); 
        f.add(text);
        f.setSize(500,500);  
        f.setLayout(null);  
        f.setVisible(true);   
    }  
    }  




