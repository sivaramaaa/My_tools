from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.widget import Widget
from kivy.uix.screenmanager import ScreenManager , Screen , FadeTransition
from kivy.lang import Builder

class MainScreen(Screen):
	pass

class SettingsScreen(Screen):
	pass

class ScreenManagement(ScreenManager):
	pass

class Widgets(Widget):
      pass

#css = Builder.load_file("simplekivy.kv")

sm = ScreenManagement()

sm.add_widget(MainScreen())
sm.add_widget(SettingsScreen())

class simplekivy(App):
       def build(self):
            return sm


if __name__ == "__main__":
     simplekivy().run()

