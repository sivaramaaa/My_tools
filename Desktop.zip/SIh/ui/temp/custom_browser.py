#from future import division, absolute_import
#from future import print_function, unicode_literals

from kivy.app import App
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.properties import ObjectProperty
from kivy.uix.popup import Popup
import kivy.resources
#from designer.app import DesignerApp
from designer.helper_functions import get_fs_encoding
from kivy.resources import resource_add_path

import os.path

from kivy.uix.spinner import Spinner
from kivy.base import runTouchApp

class SORoot(BoxLayout):

#Root of all widgets"

	send_screen = ObjectProperty(None)
	def __init__(self, **kwargs):
	    super(SORoot, self).__init__(**kwargs)
	    # List of previous screen
	    self.screen_list = []

	def changeScreen(self, next_screen):




	    if self.ids.kivy_screen_manager.current not in self.screen_list:
		self.screen_list.append(self.ids.kivy_screen_manager.current)

	    if next_screen == "about":
		self.ids.kivy_screen_manager.current = "about_screen"

	def changesScreen(self, nexts_screen):
	    if self.ids.kivy_screen_manager.current not in self.screen_list:
		self.screen_list.append(self.ids.kivy_screen_manager.current)




	    if nexts_screen == "send":
		self.ids.kivy_screen_manager.current = "send_screen"

	def changedScreen(self, nexted_screen):


	    if self.ids.kivy_screen_manager.current not in self.screen_list:
		self.screen_list.append(self.ids.kivy_screen_manager.current)

	    if nexted_screen == "receive":
		self.ids.kivy_screen_manager.current = "receive_screen"






	def onBackButton(self):
	    if self.screen_list:
		self.ids.kivy_screen_manager.current = self.screen_list.pop()
		return True
	    return False

class SOApp(App):
#App object
	def __init__(self,**kwargs):
	    super(SOApp, self).__init__(**kwargs)
	    Window.bind(on_keyboard=self.onBackButton)

	def onBackButton(self, window, key, *args):
	    if key == 27:
		return self.root.onBackButton()

	def build(self):
	    return SORoot()



	def getText(self):
	    return ("Hey! \n This is built using"
		    "\nKivy"
		    " [b]\nBy: Garvit Rishi[/b]"
		   " [b] \n Ronit Bhardwaj[/b]")



	def getTexted(self):
	    return ()


	def file(self):
	    return (" ")

if __name__ =='__main__':
       data = os.path.join(os.path.dirname(os.path.abspath('/')), 'data')
if isinstance(data, bytes):
	data = data.decode(get_fs_encoding())
	resource_add_path(data)

SOApp().run()

